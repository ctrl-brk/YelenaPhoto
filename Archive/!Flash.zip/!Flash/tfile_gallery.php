// GALLERY 

&cat_0=WEDDINGS& 

&cat_0_pic_0=1.jpg& 
&cat_0_comment_0=Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent vestibulum molestie lacus. Aenean nonummy hendrerit mauris. Phasellus porta.& 
&cat_0_pic_1=2.jpg& 
&cat_0_pic_2=3.jpg& 
&cat_0_comment_2=Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent vestibulum molestie lacus. Aenean nonummy hendrerit mauris. Phasellus porta.& 
&cat_0_pic_3=4.jpg& 
&cat_0_comment_3=Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent vestibulum molestie lacus. Aenean nonummy hendrerit mauris. Phasellus porta.& 
&cat_0_pic_4=5.jpg& 
&cat_0_comment_4=Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent vestibulum molestie lacus. Aenean nonummy hendrerit mauris. Phasellus porta.& 
&cat_0_pic_5=6.jpg& 
&cat_0_comment_5=Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent vestibulum molestie lacus. Aenean nonummy hendrerit mauris. Phasellus porta.& 
&cat_0_pic_6=7.jpg& 
&cat_0_comment_6=Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent vestibulum molestie lacus. Aenean nonummy hendrerit mauris. Phasellus porta.& 
&cat_0_pic_7=8.jpg& 
&cat_0_comment_7=Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent vestibulum molestie lacus. Aenean nonummy hendrerit mauris. Phasellus porta.& 
&cat_0_pic_8=8.jpg& 
&cat_0_pic_9=1.jpg& 
&cat_0_pic_10=2.jpg& 
&cat_0_pic_11=3.jpg& 
&cat_0_pic_12=4.jpg& 
&cat_0_pic_13=5.jpg& 
&cat_0_pic_14=6.jpg& 


&cat_1=PEOPLE& 

&cat_1_pic_0=1.jpg& 
&cat_1_comment_0=Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent vestibulum molestie lacus. Aenean nonummy hendrerit mauris. Phasellus porta.& 
&cat_1_pic_1=2.jpg& 
&cat_1_comment_1=Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent vestibulum molestie lacus. Aenean nonummy hendrerit mauris. Phasellus porta.& 
&cat_1_pic_2=3.jpg& 
&cat_1_comment_2=Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent vestibulum molestie lacus. Aenean nonummy hendrerit mauris. Phasellus porta.& 
&cat_1_pic_3=4.jpg& 
&cat_1_comment_3=Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent vestibulum molestie lacus. Aenean nonummy hendrerit mauris. Phasellus porta.& 
&cat_1_pic_4=5.jpg& 
&cat_1_comment_4=Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent vestibulum molestie lacus. Aenean nonummy hendrerit mauris. Phasellus porta.& 
&cat_1_pic_5=6.jpg& 
&cat_1_comment_5=Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent vestibulum molestie lacus. Aenean nonummy hendrerit mauris. Phasellus porta.& 
&cat_1_pic_6=7.jpg& 
&cat_1_comment_6=Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent vestibulum molestie lacus. Aenean nonummy hendrerit mauris. Phasellus porta.& 
&cat_1_pic_7=8.jpg& 
&cat_1_comment_7=Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent vestibulum molestie lacus. Aenean nonummy hendrerit mauris. Phasellus porta.& 


&cat_2=ANIMALS& 

&cat_2_pic_0=20080209_2.jpg& 
&cat_2_comment_0=Gerda. The German Shepherd. Our lovely girl. She's about 2 month old here.& 
&cat_2_pic_1=1.jpg& 
&cat_2_comment_1=Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent vestibulum molestie lacus. Aenean nonummy hendrerit mauris. Phasellus porta.& 
&cat_2_pic_2=2.jpg& 
&cat_2_comment_2=Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent vestibulum molestie lacus. Aenean nonummy hendrerit mauris. Phasellus porta.& 
&cat_2_pic_3=3.jpg& 
&cat_2_comment_3=Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent vestibulum molestie lacus. Aenean nonummy hendrerit mauris. Phasellus porta.& 
&cat_2_pic_4=4.jpg& 
&cat_2_comment_4=Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent vestibulum molestie lacus. Aenean nonummy hendrerit mauris. Phasellus porta.& 
&cat_2_pic_5=5.jpg& 
&cat_2_comment_5=Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent vestibulum molestie lacus. Aenean nonummy hendrerit mauris. Phasellus porta.& 
&cat_2_pic_6=6.jpg& 
&cat_2_comment_6=Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent vestibulum molestie lacus. Aenean nonummy hendrerit mauris. Phasellus porta.& 
&cat_2_pic_7=7.jpg& 
&cat_2_comment_7=Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent vestibulum molestie lacus. Aenean nonummy hendrerit mauris. Phasellus porta.& 
&cat_2_pic_8=8.jpg& 
&cat_2_comment_8=Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent vestibulum molestie lacus. Aenean nonummy hendrerit mauris. Phasellus porta.& 


&cat_3=NATURE& 

&cat_3_pic_0=1.jpg& 
&cat_3_comment_0=Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent vestibulum molestie lacus. Aenean nonummy hendrerit mauris. Phasellus porta.& 
&cat_3_pic_1=2.jpg& 
&cat_3_comment_1=Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent vestibulum molestie lacus. Aenean nonummy hendrerit mauris. Phasellus porta.& 
&cat_3_pic_2=3.jpg& 
&cat_3_comment_2=Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent vestibulum molestie lacus. Aenean nonummy hendrerit mauris. Phasellus porta.& 
&cat_3_pic_3=4.jpg& 
&cat_3_comment_3=Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent vestibulum molestie lacus. Aenean nonummy hendrerit mauris. Phasellus porta.& 
&cat_3_pic_4=5.jpg& 
&cat_3_comment_4=Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent vestibulum molestie lacus. Aenean nonummy hendrerit mauris. Phasellus porta.& 
&cat_3_pic_5=6.jpg& 
&cat_3_comment_5=Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent vestibulum molestie lacus. Aenean nonummy hendrerit mauris. Phasellus porta.& 
&cat_3_pic_6=7.jpg& 
&cat_3_comment_6=Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent vestibulum molestie lacus. Aenean nonummy hendrerit mauris. Phasellus porta.& 
&cat_3_pic_7=8.jpg& 
&cat_3_comment_7=Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent vestibulum molestie lacus. Aenean nonummy hendrerit mauris. Phasellus porta.& 


// PREFERENCES 

&preview_offset=7& 
&colls=1& 
&open_in_browser=false& 
&listing_offset=15& 
&comment_position=stretched& 
&image_width=134& 
&rows=1& 
&image_height=94& 
&h_space=10& 
&preview_position=left& 
&v_space=5& 


